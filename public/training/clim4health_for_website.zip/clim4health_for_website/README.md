This page contains the clim4health training materials, along with installation instructions.

NOTE: if you are participating in the HARMONIZE toolkit training course in November 2025, please follow the instructions to install the Docker environment.

If you would like to install clim4health on your local computer instead, please follow the installation instructions in local_installation_guides.Rmd.
