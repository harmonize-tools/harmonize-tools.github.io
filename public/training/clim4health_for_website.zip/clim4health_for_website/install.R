# install CRAN packages
packages <- c("devtools", "cubelyr", "measurements",
              "s2dv", "ClimProjDiags", "future",
              "qmap", "rainfarmr", "data.table", "reshape2", "ggplot2",
              "RColorBrewer", "verification", "lubridate", "scales",
              "dplyr", "ecmwfr", "exactextractr", "GHRexplore", "raster",
              "sf", "stars", "terra", "startR", "spData",
              "cli", "glue", "httr2", "lifecycle", "rlang",
              "foreign", "readxl", "writexl", "shiny", "jsonlite")

installed <- packages %in% rownames(installed.packages())
if (any(!installed)) {
  install.packages(packages[!installed],
                   repos = "https://cloud.r-project.org")
}


base_dir <- getwd()
package_path <- file.path(base_dir, "packages/")

################ temporary package installation ################

if (!"CSTools" %in% installed.packages()) {
  install.packages(file.path(package_path, "CSTools_5.2.0.tar.gz"),
                   repos = NULL, type = "source")
}